//
//  ContentView.swift
//  walking-path
//
//  Created by student on 2024/08/07.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
       // NavigationView {
//            FirebaseAuthView()
             //   .navigationTitle("Login/Signup")
            HealthView()
             //   .navigationTitle("Single/Dashboard View")
        // }
    }
}

#Preview {
    ContentView()
}
