//
//  HealthSingleView.swift
//  walking-path
//
//  Created by student on 2024/08/18.
//

import SwiftUI
import Charts

struct HealthSingleView: View {
    
    var item: HealthStat?
    
    @State var dayGoal: Int
    @State var weekGoal: Int
    @State var monthGoal: Int
    @State var yearGoal: Int
    
    @State var userProgress: Int
    
    //Func to get %
    //get % from goal.
    //if steps goals = x
    //if floor goals = y
    
//    func getPers (){
//        if item?.title == "Steps" {
//            dayGoal = 10000
//            weekGoal = 70000
//            monthGoal = 310000
//            yearGoal = 3650000
//            print("\(item?.title): \(item?.amount)")
//        } else if item?.title == "Active Energy" {
//            dayGoal = 400
//            weekGoal = 2800
//            monthGoal = 12400
//            yearGoal = 146000
//        }else if item?.title == "Resting Energy" {
//            dayGoal = 16000
//            weekGoal = 11200
//            monthGoal = 49600
//            yearGoal = 584000
//        }else if item?.title == "Walking + Running" {
//            dayGoal = 15000
//            weekGoal = 105000
//            monthGoal = 465000
//            yearGoal = 5475000
//        }else if item?.title == "Flights Climbed" {
//            dayGoal = 5
//            weekGoal = 35
//            monthGoal = 155
//            yearGoal = 1825
//        }
//    }
    func getPers() {
        guard let itemTitle = item?.title else { return }

        switch itemTitle {
        case "Steps":
            dayGoal = 10000
            weekGoal = 70000
            monthGoal = 310000
            yearGoal = 3650000
        case "Active Energy":
            dayGoal = 400
            weekGoal = 2800
            monthGoal = 12400
            yearGoal = 146000
        case "Resting Energy":
            dayGoal = 1600
            weekGoal = 11200
            monthGoal = 49600
            yearGoal = 584000
        case "Walking + Running":
            dayGoal = 15000
            weekGoal = 105000
            monthGoal = 465000
            yearGoal = 5475000
        case "Flights Climbed":
            dayGoal = 5
            weekGoal = 35
            monthGoal = 155
            yearGoal = 1825
        default:
            break
        }
        
        calculatePers()
    }
    
    func calculatePers(){
        
    }
    
    var body: some View {
        NavigationView {
        
            VStack{
                Text("")
                    .navigationTitle(item!.title)
                    .navigationBarTitleDisplayMode(.inline)
                
                VStack{
                    Text("Total of")
                        .foregroundStyle(Color.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    HStack{
                        Text(item!.amount)
                        Text(item!.title)
                            .foregroundStyle(Color.secondary)
                        Image(systemName: item!.image)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding()
                
                VStack{
                    //Grid + data
                    
                    //Require new func to get an array of data?
                    //New HealthStat model???
                    
                    //Health Stat - Current model only save total count of activity.
                    ZStack{
                        //layer shapes
                        //shape 1 ->
                        Text("\(item!.amount) vs \(dayGoal)")
                        Capsule(style: .continuous)
                            .fill(.gray)
                            .frame(width: .infinity, height: 50)
                        
                    }
                    
                }//VStack - end
                .frame(width: 250, height: 250)
                .background(item!.color)
                
                Spacer()
                
            }// VStack - outer end
            .onAppear(perform: getPers)
            
        }
    }//body - end
    
        
}

#Preview {
    HealthSingleView(dayGoal: 0, weekGoal: 0, monthGoal: 0, yearGoal: 0)
}
